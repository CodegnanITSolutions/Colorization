echo "Downloading..."
python download.py
echo "Finish download."
unzip checkpoints.zip