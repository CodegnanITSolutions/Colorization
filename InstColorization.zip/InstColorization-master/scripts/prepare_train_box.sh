DATASET_DIR=train_data/train2017

python inference_bbox.py --test_img_dir $DATASET_DIR --filter_no_obj